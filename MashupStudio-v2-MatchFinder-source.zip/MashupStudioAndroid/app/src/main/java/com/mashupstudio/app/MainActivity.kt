package com.mashupstudio.app

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class AudioTrack(val uri: Uri, val name: String, val bpm: Int? = null, val key: String = "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MashupStudioScreen() }
    }
}


private fun matchScore(a: AudioTrack, b: AudioTrack): Int {
    val bpmScore = if (a.bpm == null || b.bpm == null) 0 else {
        val ratio = maxOf(a.bpm, b.bpm).toDouble() / minOf(a.bpm, b.bpm).toDouble()
        val normalized = if (ratio > 1.06 && ratio / 2.0 <= 1.06) ratio / 2.0 else ratio
        if (normalized > 1.06) 0 else (100 - ((normalized - 1.0) * 450).toInt()).coerceIn(0, 100)
    }
    val keyScore = when {
        a.key.isBlank() || b.key.isBlank() -> 0
        a.key.equals(b.key, true) -> 100
        else -> {
            val relatives = mapOf("C" to "Am", "Am" to "C", "G" to "Em", "Em" to "G", "D" to "Bm", "Bm" to "D", "A" to "F#m", "F#m" to "A", "E" to "C#m", "C#m" to "E", "F" to "Dm", "Dm" to "F", "Bb" to "Gm", "Gm" to "Bb")
            if (relatives[a.key] == b.key) 85 else 0
        }
    }
    return when { bpmScore == 0 && keyScore == 0 -> 0; bpmScore == 0 -> keyScore * 45 / 100; keyScore == 0 -> bpmScore * 55 / 100; else -> (bpmScore * 0.55 + keyScore * 0.45).toInt() }
}

@Composable
fun MashupStudioScreen() {
    val context = LocalContext.current
    val tracks = remember { mutableStateListOf<AudioTrack>() }
    var selectedA by remember { mutableStateOf<AudioTrack?>(null) }
    var selectedB by remember { mutableStateOf<AudioTrack?>(null) }
    var playing by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf("Importa i tuoi brani audio per iniziare.") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var editing by remember { mutableStateOf<AudioTrack?>(null) }
    var bpmInput by remember { mutableStateOf("") }
    var keyInput by remember { mutableStateOf("") }

    DisposableEffect(Unit) {
        onDispose { player?.release() }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(
                        uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {}
                val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && index >= 0) cursor.getString(index) else null
                } ?: "Traccia audio"
                if (tracks.none { it.uri == uri }) tracks.add(AudioTrack(uri, name))
            }
            status = "${uris.size} file selezionati. Scegli Track A e Track B."
        } else {
            status = "Nessun file selezionato."
        }
    }

    fun playTrack(track: AudioTrack?) {
        if (track == null) {
            status = "Seleziona prima una traccia."
            return
        }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(context, track.uri)
                setOnPreparedListener {
                    it.start()
                    playing = true
                    status = "In riproduzione: ${track.name}"
                }
                setOnCompletionListener {
                    playing = false
                    status = "Riproduzione terminata."
                }
                setOnErrorListener { _, _, _ ->
                    playing = false
                    status = "Impossibile riprodurre questo formato audio."
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            status = "Non riesco ad aprire questo file audio."
        }
    }

    val bg = Brush.verticalGradient(listOf(Color(0xFF111020), Color(0xFF20133D), Color(0xFF0B0B14)))
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF9A7BFF),
        secondary = Color(0xFF47D7D0),
        background = Color(0xFF111020),
        surface = Color(0xFF211D35)
    )) {
        Column(
            modifier = Modifier.fillMaxSize().background(bg).padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("MASHUP STUDIO", color = Color(0xFFBBA8FF), fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("MATCH FINDER", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("La tua console musicale", color = Color.LightGray, fontSize = 14.sp)

            Button(
                onClick = { picker.launch(arrayOf("audio/*")) },
                modifier = Modifier.fillMaxWidth().height(54.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("＋  SCEGLI FILE AUDIO", fontWeight = FontWeight.Bold) }

            Text(status, color = Color(0xFFBDB7D0), fontSize = 12.sp)

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC211D35)), modifier = Modifier.weight(1f)) {
                Column(Modifier.padding(14.dp)) {
                    Text("LA TUA LIBRERIA  ·  ${tracks.size} BRANI", color = Color.White, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (tracks.isEmpty()) {
                        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                            Text("I brani importati appariranno qui.", color = Color.Gray)
                        }
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(tracks) { track ->
                                Row(
                                    Modifier.fillMaxWidth().background(Color(0xFF30294A), RoundedCornerShape(10.dp)).padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(track.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                        Text("${track.bpm?.let { "$it BPM" } ?: "BPM —"} · ${track.key.ifBlank { "Tonalità —" }}", color = Color.LightGray, fontSize = 10.sp)
                                    }
                                    TextButton(onClick = { editing = track; bpmInput = track.bpm?.toString() ?: ""; keyInput = track.key }) { Text("ANALIZZA", fontSize = 9.sp) }
                                    TextButton(onClick = { selectedA = track; status = "Track A: ${track.name}" }) { Text("A") }
                                    TextButton(onClick = { selectedB = track; status = "Track B: ${track.name}" }) { Text("B") }
                                    TextButton(onClick = { playTrack(track) }) { Text("▶") }
                                }
                            }
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC211D35))) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("MATCH FINDER", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("BRANO BASE · ${selectedA?.name ?: "Seleziona A dalla libreria"}", color = Color(0xFFBBA8FF), fontSize = 11.sp, maxLines = 1)
                    val matches = selectedA?.let { base -> tracks.filter { it.uri != base.uri }.map { it to matchScore(base, it) }.sortedByDescending { it.second } } ?: emptyList()
                    if (matches.isEmpty()) Text("Importa un secondo brano e scegli A per confrontarlo.", color = Color.LightGray, fontSize = 10.sp)
                    matches.take(3).forEach { (track, score) ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(track.name, color = Color.White, fontSize = 11.sp, modifier = Modifier.weight(1f), maxLines = 1)
                            Text(if (score > 0) "$score/100" else "DATI MANCANTI", color = Color(0xFF47D7D0), fontSize = 10.sp)
                            TextButton(onClick = { selectedB = track }) { Text("USA B") }
                        }
                    }
                }
            }

            Card(colors = CardDefaults.cardColors(containerColor = Color(0xCC211D35))) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("MIXER", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("TRACK A  ·  ${selectedA?.name ?: "Non selezionata"}", color = Color(0xFFBBA8FF), fontSize = 12.sp)
                    Text("TRACK B  ·  ${selectedB?.name ?: "Non selezionata"}", color = Color(0xFF47D7D0), fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { playTrack(selectedA) }, modifier = Modifier.weight(1f)) { Text("▶ PLAY A") }
                        OutlinedButton(onClick = { playTrack(selectedB) }, modifier = Modifier.weight(1f)) { Text("▶ PLAY B") }
                    }
                }
            }
            Text("Match Finder v2.0 · confronto BPM e tonalità. In questa build i dati si inseriscono manualmente; l’analisi audio automatica sarà il prossimo modulo.", color = Color.Gray, fontSize = 10.sp)
        }
    }
    editing?.let { track ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("Analisi brano") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(track.name, fontSize = 12.sp)
                    OutlinedTextField(value = bpmInput, onValueChange = { bpmInput = it.filter { c -> c.isDigit() }.take(3) }, label = { Text("BPM (es. 120)") }, singleLine = true)
                    OutlinedTextField(value = keyInput, onValueChange = { keyInput = it }, label = { Text("Tonalità (es. Am, C, F#m)") }, singleLine = true)
                }
            },
            confirmButton = { TextButton(onClick = {
                val idx = tracks.indexOfFirst { it.uri == track.uri }
                if (idx >= 0) tracks[idx] = track.copy(bpm = bpmInput.toIntOrNull()?.takeIf { it in 40..240 }, key = keyInput.trim())
                editing = null
                status = "Dati salvati per ${track.name}."
            }) { Text("SALVA") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("ANNULLA") } }
        )
    }

}
