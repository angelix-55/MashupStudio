package com.mashupstudio.app

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.content.Context
import kotlin.math.*

 data class AudioAnalysis(val bpm: Int?, val key: String?, val energy: String, val durationMs: Long, val confidence: Int)

object AudioAnalyzer {
    fun analyze(context: Context, uri: Uri): AudioAnalysis {
        val decoded = decode(context, uri)
        val samples = decoded.first
        val sampleRate = decoded.second
        if (samples.size < sampleRate * 5) return AudioAnalysis(null, null, "Non disponibile", decoded.third, 0)
        val frame = 1024
        val envelope = ArrayList<Double>()
        var i = 0
        while (i + frame < samples.size) {
            var sum = 0.0
            for (j in 0 until frame) { val v = samples[i + j].toDouble(); sum += v * v }
            envelope.add(sqrt(sum / frame))
            i += frame
        }
        val onset = DoubleArray(envelope.size)
        for (n in 1 until envelope.size) onset[n] = max(0.0, envelope[n] - envelope[n - 1])
        val envRate = sampleRate.toDouble() / frame
        var bestLag = -1
        var best = 0.0
        var second = 0.0
        val minLag = max(1, (envRate * 60.0 / 180.0).roundToInt())
        val maxLag = max(minLag + 1, (envRate * 60.0 / 65.0).roundToInt())
        for (lag in minLag..min(maxLag, onset.size / 2)) {
            var corr = 0.0
            var normA = 0.0
            var normB = 0.0
            for (n in lag until onset.size) {
                corr += onset[n] * onset[n - lag]
                normA += onset[n] * onset[n]
                normB += onset[n - lag] * onset[n - lag]
            }
            val score = if (normA * normB > 0) corr / sqrt(normA * normB) else 0.0
            if (score > best) { second = best; best = score; bestLag = lag } else if (score > second) second = score
        }
        val bpm = if (bestLag > 0) (60.0 * envRate / bestLag).roundToInt().coerceIn(60, 180) else null
        val key = estimateKey(samples, sampleRate)
        val rms = sqrt(samples.sumOf { it.toDouble() * it.toDouble() } / samples.size)
        val energy = when { rms < .035 -> "Bassa"; rms < .10 -> "Media"; else -> "Alta" }
        val confidence = if (best > 0) ((best * 100).roundToInt()).coerceIn(0, 99) else 0
        return AudioAnalysis(bpm, key, energy, decoded.third, confidence)
    }

    private fun decode(context: Context, uri: Uri): Triple<FloatArray, Int, Long> {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        var track = -1
        var format: MediaFormat? = null
        for (n in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(n)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) { track = n; format = f; break }
        }
        require(track >= 0 && format != null) { "File audio non supportato" }
        extractor.selectTrack(track)
        val mime = format!!.getString(MediaFormat.KEY_MIME)!!
        val duration = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) / 1000 else 0L
        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(format, null, null, 0)
        codec.start()
        val out = ArrayList<Float>(2_000_000)
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var outRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        var channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        var pcmEncoding = AudioFormat.ENCODING_PCM_16BIT
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inputIndex = codec.dequeueInputBuffer(10000)
                    if (inputIndex >= 0) {
                        val input = codec.getInputBuffer(inputIndex)!!
                        val size = extractor.readSampleData(input, 0)
                        if (size < 0) { codec.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputDone = true }
                        else { codec.queueInputBuffer(inputIndex, 0, size, extractor.sampleTime, 0); extractor.advance() }
                    }
                }
                val outputIndex = codec.dequeueOutputBuffer(info, 10000)
                when {
                    outputIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        outRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        if (of.containsKey(MediaFormat.KEY_PCM_ENCODING)) pcmEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    }
                    outputIndex >= 0 -> {
                        val buffer = codec.getOutputBuffer(outputIndex)
                        if (buffer != null && info.size > 0) {
                            buffer.position(info.offset); buffer.limit(info.offset + info.size)
                            if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                                while (buffer.remaining() >= 4) out.add(buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN).float.coerceIn(-1f, 1f))
                            } else {
                                while (buffer.remaining() >= 2) out.add(buffer.order(java.nio.ByteOrder.LITTLE_ENDIAN).short / 32768f)
                            }
                        }
                        outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                        codec.releaseOutputBuffer(outputIndex, false)
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release(); extractor.release()
        }
        // Convert interleaved channels to mono and downsample to 11.025 kHz for efficient analysis.
        val mono = ArrayList<Float>(out.size / max(1, channels))
        var p = 0
        while (p + channels <= out.size) {
            var sum = 0f
            for (c in 0 until channels) sum += out[p + c]
            mono.add(sum / channels)
            p += channels
        }
        val step = max(1, outRate / 11025)
        val reduced = FloatArray((mono.size + step - 1) / step)
        var dst = 0; p = 0
        while (p < mono.size) { reduced[dst++] = mono[p]; p += step }
        return Triple(reduced, max(1, outRate / step), duration)
    }

    private fun estimateKey(samples: FloatArray, sampleRate: Int): String? {
        val n = 4096
        if (samples.size < n) return null
        val chroma = DoubleArray(12)
        val hop = 2048
        val real = DoubleArray(n); val imag = DoubleArray(n)
        var start = 0; var frames = 0
        while (start + n <= samples.size && frames < 1000) {
            for (i in 0 until n) {
                val window = 0.5 - 0.5 * cos(2.0 * Math.PI * i / (n - 1))
                real[i] = samples[start + i] * window; imag[i] = 0.0
            }
            fft(real, imag)
            for (bin in 2 until n / 2) {
                val freq = bin.toDouble() * sampleRate / n
                if (freq < 55 || freq > 2000) continue
                val midi = (69 + 12 * ln(freq / 440.0) / ln(2.0)).roundToInt()
                val pitch = ((midi % 12) + 12) % 12
                chroma[pitch] += hypot(real[bin], imag[bin])
            }
            start += hop; frames++
        }
        if (chroma.sum() <= 0.0) return null
        val major = doubleArrayOf(6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88)
        val minor = doubleArrayOf(6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17)
        val names = arrayOf("C","C#","D","D#","E","F","F#","G","G#","A","Bb","B")
        var best = Double.NEGATIVE_INFINITY; var answer: String? = null
        for (shift in 0 until 12) for (mode in 0..1) {
            val profile = if (mode == 0) major else minor
            var score = 0.0
            for (i in 0 until 12) score += chroma[(i + shift) % 12] * profile[i]
            if (score > best) { best = score; answer = names[shift] + if (mode == 0) "" else "m" }
        }
        return answer
    }

    private fun fft(real: DoubleArray, imag: DoubleArray) {
        val n = real.size
        var j = 0
        for (i in 1 until n) {
            var bit = n shr 1
            while (j and bit != 0) { j = j xor bit; bit = bit shr 1 }
            j = j xor bit
            if (i < j) { val tr = real[i]; real[i] = real[j]; real[j] = tr; val ti = imag[i]; imag[i] = imag[j]; imag[j] = ti }
        }
        var len = 2
        while (len <= n) {
            val angle = -2.0 * Math.PI / len
            val wLenR = cos(angle); val wLenI = sin(angle)
            var i = 0
            while (i < n) {
                var wr = 1.0; var wi = 0.0
                for (k in 0 until len / 2) {
                    val uR = real[i + k]; val uI = imag[i + k]
                    val vR = real[i + k + len / 2] * wr - imag[i + k + len / 2] * wi
                    val vI = real[i + k + len / 2] * wi + imag[i + k + len / 2] * wr
                    real[i + k] = uR + vR; imag[i + k] = uI + vI
                    real[i + k + len / 2] = uR - vR; imag[i + k + len / 2] = uI - vI
                    val next = wr * wLenR - wi * wLenI; wi = wr * wLenI + wi * wLenR; wr = next
                }
                i += len
            }
            len = len shl 1
        }
    }
}
