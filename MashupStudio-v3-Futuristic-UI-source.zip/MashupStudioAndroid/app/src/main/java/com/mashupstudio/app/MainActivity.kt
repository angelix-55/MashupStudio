package com.mashupstudio.app

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Void = Color(0xFF080B16)
private val Panel = Color(0xFF111A2B)
private val Panel2 = Color(0xFF17243A)
private val Violet = Color(0xFF9B6DFF)
private val Cyan = Color(0xFF45E5E0)
private val Muted = Color(0xFF91A1B9)

data class AudioTrack(val uri: Uri, val name: String, val bpm: Int? = null, val key: String = "")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MashupStudioScreen() }
    }
}

private fun matchScore(a: AudioTrack, b: AudioTrack): Int {
    val bpmScore = if (a.bpm == null || b.bpm == null) 0 else {
        val ratio = maxOf(a.bpm, b.bpm).toDouble() / minOf(a.bpm, b.bpm).toDouble()
        val normalized = if (ratio > 1.06 && ratio / 2.0 <= 1.06) ratio / 2.0 else ratio
        if (normalized > 1.06) 0 else (100 - ((normalized - 1.0) * 450).toInt()).coerceIn(0, 100)
    }
    val keyScore = when {
        a.key.isBlank() || b.key.isBlank() -> 0
        a.key.equals(b.key, true) -> 100
        else -> {
            val relatives = mapOf("C" to "Am", "Am" to "C", "G" to "Em", "Em" to "G", "D" to "Bm", "Bm" to "D", "A" to "F#m", "F#m" to "A", "E" to "C#m", "C#m" to "E", "F" to "Dm", "Dm" to "F", "Bb" to "Gm", "Gm" to "Bb")
            if (relatives[a.key] == b.key) 85 else 0
        }
    }
    return when {
        bpmScore == 0 && keyScore == 0 -> 0
        bpmScore == 0 -> keyScore * 45 / 100
        keyScore == 0 -> bpmScore * 55 / 100
        else -> (bpmScore * 0.55 + keyScore * 0.45).toInt()
    }
}

@Composable
fun MashupStudioScreen() {
    val context = LocalContext.current
    val tracks = remember { mutableStateListOf<AudioTrack>() }
    var selectedA by remember { mutableStateOf<AudioTrack?>(null) }
    var selectedB by remember { mutableStateOf<AudioTrack?>(null) }
    var status by remember { mutableStateOf("Importa i tuoi brani per iniziare il tuo studio.") }
    var player by remember { mutableStateOf<MediaPlayer?>(null) }
    var editing by remember { mutableStateOf<AudioTrack?>(null) }
    var bpmInput by remember { mutableStateOf("") }
    var keyInput by remember { mutableStateOf("") }
    var tab by remember { mutableStateOf("HOME") }

    DisposableEffect(Unit) { onDispose { player?.release() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val i = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && i >= 0) cursor.getString(i) else null
                } ?: "Traccia audio"
                if (tracks.none { it.uri == uri }) tracks.add(AudioTrack(uri, name))
            }
            status = "${uris.size} brani aggiunti alla libreria."
        } else status = "Nessun file selezionato."
    }

    fun playTrack(track: AudioTrack?) {
        if (track == null) { status = "Seleziona prima una traccia."; return }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(context, track.uri)
                setOnPreparedListener { it.start(); status = "In riproduzione: ${track.name}" }
                setOnCompletionListener { status = "Riproduzione terminata." }
                setOnErrorListener { _, _, _ -> status = "Formato audio non supportato."; true }
                prepareAsync()
            }
        } catch (_: Exception) { status = "Impossibile aprire questo file audio." }
    }

    val matches = selectedA?.let { base ->
        tracks.filter { it.uri != base.uri }.map { it to matchScore(base, it) }.sortedByDescending { it.second }
    } ?: emptyList()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Violet, secondary = Cyan, background = Void, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Column(
            Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10182B), Void, Color(0xFF090D19)))).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalArrangement = Arrangement.spacedBy(13.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                    Text("M", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
                }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("MASHUP STUDIO", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 1.5.sp)
                    Text("AI MUSIC WORKSPACE  ·  3.0 CONCEPT", color = Cyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                }
                Box(Modifier.border(1.dp, Cyan.copy(alpha = .45f), CircleShape).padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text("● READY", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF28204B), Color(0xFF123144))), RoundedCornerShape(20.dp)).padding(16.dp)) {
                Text("YOUR SOUND. YOUR RULES.", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Black)
                Text("Crea, abbina e sperimenta con la tua musica.", color = Color(0xFFD1D9EB), fontSize = 11.sp)
                Spacer(Modifier.height(13.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatPill("${tracks.size}", "BRANI", Modifier.weight(1f))
                    StatPill(selectedA?.bpm?.toString() ?: "—", "BPM A", Modifier.weight(1f))
                    StatPill(selectedA?.key?.ifBlank { "—" } ?: "—", "KEY A", Modifier.weight(1f))
                }
            }

            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("HOME", "MATCH", "MIXER", "STUDIO").forEach { item ->
                    val active = tab == item
                    TextButton(
                        onClick = { tab = item },
                        modifier = Modifier.weight(1f).background(if (active) Brush.horizontalGradient(listOf(Violet.copy(alpha = .8f), Color(0xFF4C74B8))) else Brush.horizontalGradient(listOf(Panel, Panel)), RoundedCornerShape(10.dp)),
                        contentPadding = PaddingValues(vertical = 8.dp)
                    ) { Text(item, color = if (active) Color.White else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                }
            }

            when (tab) {
                "HOME" -> {
                    SectionHeader("CONTROL CENTER", "La tua postazione musicale")
                    ActionTile("＋  IMPORTA BRANI", "Aggiungi file audio alla libreria", Violet) { picker.launch(arrayOf("audio/*")) }
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        MiniTile("01", "SMART ANALYSIS", "BPM · tonalità", Modifier.weight(1f), Cyan) { tab = "MATCH" }
                        MiniTile("02", "AI MATCH", "Trova abbinamenti", Modifier.weight(1f), Violet) { tab = "MATCH" }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        MiniTile("03", "DUAL MIXER", "Due tracce", Modifier.weight(1f), Cyan) { tab = "MIXER" }
                        MiniTile("04", "MASHUP CREATOR", "Timeline editor", Modifier.weight(1f), Violet) { tab = "STUDIO" }
                    }
                    SectionHeader("RECENT TRACKS", "${tracks.size} nella libreria")
                    TrackLibrary(tracks, selectedA, selectedB, onAnalyze = { t -> editing = t; bpmInput = t.bpm?.toString() ?: ""; keyInput = t.key }, onA = { selectedA = it; status = "Track A: ${it.name}" }, onB = { selectedB = it; status = "Track B: ${it.name}" }, onPlay = { playTrack(it) })
                }
                "MATCH" -> {
                    SectionHeader("SMART ANALYSIS", "I dati audio si inseriscono manualmente in questa build")
                    ActionTile("＋  IMPORTA BRANI", "Aggiungi le tracce da confrontare", Violet) { picker.launch(arrayOf("audio/*")) }
                    SectionHeader("AI MATCH FINDER", selectedA?.name ?: "Scegli Track A dalla libreria")
                    if (tracks.isEmpty()) Text("La libreria è vuota. Importa prima i tuoi brani.", color = Muted, fontSize = 12.sp)
                    else TrackLibrary(tracks, selectedA, selectedB, onAnalyze = { t -> editing = t; bpmInput = t.bpm?.toString() ?: ""; keyInput = t.key }, onA = { selectedA = it }, onB = { selectedB = it }, onPlay = { playTrack(it) })
                    matches.take(5).forEach { (track, score) ->
                        Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(12.dp)).padding(11.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(track.name, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${track.bpm?.let { "$it BPM" } ?: "BPM —"}  ·  ${track.key.ifBlank { "Tonalità —" }}", color = Muted, fontSize = 9.sp)
                            }
                            Text(if (score > 0) "$score/100" else "DATI —", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            TextButton(onClick = { selectedB = track }) { Text("USA B", fontSize = 9.sp) }
                        }
                    }
                    Text(status, color = Muted, fontSize = 10.sp)
                }
                "MIXER" -> {
                    SectionHeader("DUAL DECK", "Seleziona due brani dalla libreria")
                    DeckCard("DECK A", selectedA, Violet, onPlay = { playTrack(selectedA) })
                    DeckCard("DECK B", selectedB, Cyan, onPlay = { playTrack(selectedB) })
                    Text("Il mixer simultaneo, il crossfader e la sincronizzazione automatica saranno implementati in una fase successiva.", color = Muted, fontSize = 11.sp)
                    TrackLibrary(tracks, selectedA, selectedB, onAnalyze = { t -> editing = t; bpmInput = t.bpm?.toString() ?: ""; keyInput = t.key }, onA = { selectedA = it }, onB = { selectedB = it }, onPlay = { playTrack(it) })
                }
                else -> {
                    SectionHeader("MASHUP CREATOR", "Il tuo spazio creativo")
                    Box(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("PROJECT TIMELINE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            WaveformStrip(Violet)
                            Text(selectedA?.name ?: "TRACK A · non selezionata", color = Muted, fontSize = 10.sp, maxLines = 1)
                            WaveformStrip(Cyan)
                            Text(selectedB?.name ?: "TRACK B · non selezionata", color = Muted, fontSize = 10.sp, maxLines = 1)
                            Text("00:00       00:30       01:00       01:30", color = Muted, fontSize = 8.sp)
                        }
                    }
                    Text("Questa è l'anteprima dell'editor: taglio, allineamento, transizioni ed esportazione verranno collegati nei prossimi moduli.", color = Muted, fontSize = 11.sp)
                    TrackLibrary(tracks, selectedA, selectedB, onAnalyze = { t -> editing = t; bpmInput = t.bpm?.toString() ?: ""; keyInput = t.key }, onA = { selectedA = it }, onB = { selectedB = it }, onPlay = { playTrack(it) })
                }
            }
            Spacer(Modifier.weight(1f, fill = false))
            Text(status, color = Muted, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }

    editing?.let { track ->
        AlertDialog(
            onDismissRequest = { editing = null },
            title = { Text("DATI TRACCIA") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(track.name, fontSize = 12.sp)
                    OutlinedTextField(value = bpmInput, onValueChange = { bpmInput = it.filter(Char::isDigit).take(3) }, label = { Text("BPM (40–240)") }, singleLine = true)
                    OutlinedTextField(value = keyInput, onValueChange = { keyInput = it }, label = { Text("Tonalità (es. Am, C, F#m)") }, singleLine = true)
                }
            },
            confirmButton = { TextButton(onClick = {
                val idx = tracks.indexOfFirst { it.uri == track.uri }
                if (idx >= 0) tracks[idx] = track.copy(bpm = bpmInput.toIntOrNull()?.takeIf { it in 40..240 }, key = keyInput.trim())
                if (selectedA?.uri == track.uri) selectedA = tracks.getOrNull(idx)
                if (selectedB?.uri == track.uri) selectedB = tracks.getOrNull(idx)
                editing = null
                status = "Dati salvati: ${track.name}"
            }) { Text("SALVA") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("ANNULLA") } }
        )
    }
}

@Composable
private fun StatPill(value: String, label: String, modifier: Modifier) {
    Column(modifier.background(Color.Black.copy(alpha = .2f), RoundedCornerShape(10.dp)).padding(9.dp)) {
        Text(value, color = Color.White, fontWeight = FontWeight.Black, fontSize = 16.sp)
        Text(label, color = Color(0xFFB8C6DF), fontSize = 8.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SectionHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
        Text(subtitle, color = Muted, fontSize = 10.sp)
    }
}

@Composable
private fun ActionTile(title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Button(onClick = onClick, modifier = Modifier.fillMaxWidth().height(54.dp), shape = RoundedCornerShape(14.dp), colors = ButtonDefaults.buttonColors(containerColor = accent)) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Black)
            Text(subtitle, color = Color.White.copy(alpha = .8f), fontSize = 9.sp)
        }
    }
}

@Composable
private fun MiniTile(number: String, title: String, subtitle: String, modifier: Modifier, accent: Color, onClick: () -> Unit) {
    Surface(onClick = onClick, modifier = modifier, color = Panel, shape = RoundedCornerShape(15.dp), border = androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha = .28f))) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(number, color = accent, fontSize = 9.sp, fontWeight = FontWeight.Black)
            Text(title, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            Text(subtitle, color = Muted, fontSize = 9.sp)
        }
    }
}

@Composable
private fun TrackLibrary(
    tracks: List<AudioTrack>, selectedA: AudioTrack?, selectedB: AudioTrack?,
    onAnalyze: (AudioTrack) -> Unit, onA: (AudioTrack) -> Unit, onB: (AudioTrack) -> Unit, onPlay: (AudioTrack) -> Unit
) {
    if (tracks.isEmpty()) {
        Text("Nessun brano importato.", color = Muted, fontSize = 11.sp)
    } else {
        LazyColumn(Modifier.heightIn(max = 270.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(tracks, key = { it.uri.toString() }) { track ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 9.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(track.name, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("${track.bpm?.let { "$it BPM" } ?: "BPM —"} · ${track.key.ifBlank { "KEY —" }}", color = Muted, fontSize = 9.sp)
                    }
                    TextButton(onClick = { onAnalyze(track) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("DATI", color = Violet, fontSize = 9.sp) }
                    TextButton(onClick = { onA(track) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text(if (selectedA?.uri == track.uri) "A✓" else "A", color = Violet, fontSize = 10.sp) }
                    TextButton(onClick = { onB(track) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text(if (selectedB?.uri == track.uri) "B✓" else "B", color = Cyan, fontSize = 10.sp) }
                    TextButton(onClick = { onPlay(track) }, contentPadding = PaddingValues(horizontal = 4.dp)) { Text("▶", color = Color.White, fontSize = 10.sp) }
                }
            }
        }
    }
}

@Composable
private fun DeckCard(title: String, track: AudioTrack?, accent: Color, onPlay: () -> Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).border(1.dp, accent.copy(alpha = .35f), RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = accent, fontWeight = FontWeight.Black, fontSize = 10.sp, letterSpacing = 1.sp)
        Text(track?.name ?: "Nessuna traccia selezionata", color = Color.White, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${track?.bpm?.let { "$it BPM" } ?: "BPM —"} · ${track?.key?.ifBlank { "KEY —" } ?: "KEY —"}", color = Muted, fontSize = 10.sp)
        Button(onClick = onPlay, colors = ButtonDefaults.buttonColors(containerColor = accent), shape = RoundedCornerShape(10.dp)) { Text("▶  PLAY", fontSize = 10.sp) }
    }
}

@Composable
private fun WaveformStrip(accent: Color) {
    Row(Modifier.fillMaxWidth().height(34.dp).background(Color(0xFF0A1020), RoundedCornerShape(8.dp)).padding(horizontal = 5.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
        val heights = listOf(8, 17, 12, 25, 16, 29, 12, 21, 31, 17, 10, 25, 14, 28, 18, 11, 24, 15, 30, 12, 20, 9, 26, 15, 22, 11)
        heights.forEachIndexed { index, h ->
            Box(Modifier.width(3.dp).height(h.dp).background(accent.copy(alpha = if (index % 3 == 0) .95f else .55f), RoundedCornerShape(3.dp)))
        }
    }
}
