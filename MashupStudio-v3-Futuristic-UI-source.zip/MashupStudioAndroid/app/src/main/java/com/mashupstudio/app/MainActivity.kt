package com.mashupstudio.app

import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Void = Color(0xFF080B16)
private val Panel = Color(0xFF111A2B)
private val Panel2 = Color(0xFF17243A)
private val Violet = Color(0xFF9B6DFF)
private val Cyan = Color(0xFF45E5E0)
private val Muted = Color(0xFF91A1B9)

data class AudioTrack(
    val uri: Uri, val name: String, val bpm: Int? = null, val key: String? = null,
    val energy: String? = null, val durationMs: Long = 0L, val confidence: Int = 0, val analyzed: Boolean = false
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MashupStudioScreen() }
    }
}

private fun matchScore(a: AudioTrack, b: AudioTrack): Int {
    val bpmScore = if (a.bpm == null || b.bpm == null) 0 else {
        val ratio = maxOf(a.bpm, b.bpm).toDouble() / minOf(a.bpm, b.bpm).toDouble()
        val normalized = if (ratio > 1.06 && ratio / 2.0 <= 1.06) ratio / 2.0 else ratio
        if (normalized > 1.06) 0 else (100 - ((normalized - 1.0) * 450).toInt()).coerceIn(0, 100)
    }
    val keyScore = when {
        a.key.isNullOrBlank() || b.key.isNullOrBlank() -> 0
        a.key.equals(b.key, true) -> 100
        else -> {
            val relatives = mapOf("C" to "Am", "Am" to "C", "G" to "Em", "Em" to "G", "D" to "Bm", "Bm" to "D", "A" to "F#m", "F#m" to "A", "E" to "C#m", "C#m" to "E", "F" to "Dm", "Dm" to "F", "Bb" to "Gm", "Gm" to "Bb")
            if (relatives[a.key] == b.key) 85 else 0
        }
    }
    return when { bpmScore == 0 && keyScore == 0 -> 0; bpmScore == 0 -> keyScore * 45 / 100; keyScore == 0 -> bpmScore * 55 / 100; else -> (bpmScore * .55 + keyScore * .45).toInt() }
}

@Composable
fun MashupStudioScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val tracks = remember { mutableStateListOf<AudioTrack>() }
    var selectedA by remember { mutableStateOf<AudioTrack?>(null) }
    var selectedB by remember { mutableStateOf<AudioTrack?>(null) }
    var status by remember { mutableStateOf("Benvenuto! Importa due brani e inizia a creare.") }
    var tab by remember { mutableStateOf("HOME") }
    var analyzingUri by remember { mutableStateOf<String?>(null) }
    var crossfade by remember { mutableFloatStateOf(.5f) }
    var volumeA by remember { mutableFloatStateOf(1f) }
    var volumeB by remember { mutableFloatStateOf(1f) }
    var syncEnabled by remember { mutableStateOf(true) }
    var playerA by remember { mutableStateOf<MediaPlayer?>(null) }
    var playerB by remember { mutableStateOf<MediaPlayer?>(null) }
    var playingA by remember { mutableStateOf(false) }
    var playingB by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { try { playerA?.release() } catch (_: Exception) {}; try { playerB?.release() } catch (_: Exception) {} }
    }

    fun updateVolumes() {
        playerA?.setVolume(volumeA * (1f - crossfade), volumeA * (1f - crossfade))
        playerB?.setVolume(volumeB * crossfade, volumeB * crossfade)
    }
    LaunchedEffect(crossfade, volumeA, volumeB) { updateVolumes() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            uris.forEach { uri ->
                try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                val name = context.contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                    val i = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (cursor.moveToFirst() && i >= 0) cursor.getString(i) else null
                } ?: "Traccia audio"
                if (tracks.none { it.uri == uri }) tracks.add(AudioTrack(uri, name))
            }
            status = "${uris.size} brani aggiunti. Premi ANALIZZA per conoscerli."
        }
    }

    fun analyzeTrack(track: AudioTrack) {
        if (analyzingUri != null) return
        analyzingUri = track.uri.toString()
        status = "Analisi audio in corso: ${track.name}…"
        scope.launch {
            val result = withContext(Dispatchers.IO) { runCatching { AudioAnalyzer.analyze(context, track.uri) } }
            val idx = tracks.indexOfFirst { it.uri == track.uri }
            if (idx >= 0) {
                result.onSuccess { a ->
                    val updated = track.copy(bpm = a.bpm, key = a.key, energy = a.energy, durationMs = a.durationMs, confidence = a.confidence, analyzed = true)
                    tracks[idx] = updated
                    if (selectedA?.uri == track.uri) selectedA = updated
                    if (selectedB?.uri == track.uri) selectedB = updated
                    status = "Analisi completata: ${a.bpm?.let { "$it BPM" } ?: "BPM non rilevato"} · ${a.key ?: "tonalità non rilevata"}."
                }.onFailure { status = "Analisi non riuscita per questo formato. Prova un altro file audio." }
            }
            analyzingUri = null
        }
    }

    fun stopDeckA() { try { playerA?.stop() } catch (_: Exception) {}; try { playerA?.release() } catch (_: Exception) {}; playerA = null; playingA = false }
    fun stopDeckB() { try { playerB?.stop() } catch (_: Exception) {}; try { playerB?.release() } catch (_: Exception) {}; playerB = null; playingB = false }

    fun startDeck(track: AudioTrack?, deckA: Boolean) {
        if (track == null) { status = "Scegli prima una canzone per questo deck."; return }
        if (deckA) stopDeckA() else stopDeckB()
        try {
            val mp = MediaPlayer()
            mp.setDataSource(context, track.uri)
            mp.setOnPreparedListener { ready ->
                if (syncEnabled && track.bpm != null && selectedA?.bpm != null && !deckA) {
                    val speed = (selectedA!!.bpm!!.toFloat() / track.bpm!!.toFloat()).coerceIn(.85f, 1.15f)
                    try { ready.playbackParams = ready.playbackParams.setSpeed(speed) } catch (_: Exception) {}
                }
                ready.setVolume(if (deckA) volumeA * (1f-crossfade) else volumeB * crossfade, if (deckA) volumeA * (1f-crossfade) else volumeB * crossfade)
                ready.start()
                if (deckA) playingA = true else playingB = true
                status = "In riproduzione: ${track.name}"
            }
            mp.setOnCompletionListener { if (deckA) playingA = false else playingB = false }
            mp.setOnErrorListener { _, _, _ -> status = "Impossibile riprodurre questa traccia."; true }
            if (deckA) playerA = mp else playerB = mp
            mp.prepareAsync()
        } catch (_: Exception) { status = "Impossibile aprire il file audio." }
    }

    fun createMashup() {
        if (selectedA == null || selectedB == null) { status = "Seleziona una canzone per Deck A e una per Deck B."; tab = "HOME"; return }
        crossfade = .5f
        startDeck(selectedA, true)
        startDeck(selectedB, false)
        tab = "MIXER"
        status = "Mashup in ascolto! Regola il crossfader per bilanciare i due brani."
    }

    val matches = selectedA?.let { base -> tracks.filter { it.uri != base.uri && it.analyzed }.map { it to matchScore(base, it) }.sortedByDescending { it.second } } ?: emptyList()

    MaterialTheme(colorScheme = darkColorScheme(primary = Violet, secondary = Cyan, background = Void, surface = Panel, onBackground = Color.White, onSurface = Color.White)) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF10182B), Void, Color(0xFF090D19)))).padding(horizontal = 16.dp, vertical = 12.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Violet, Cyan)), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) { Text("M", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black) }
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("MASHUP STUDIO", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Black, letterSpacing = 1.4.sp)
                    Text("CREATE MUSIC YOUR WAY  ·  3.1", color = Cyan, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                }
                Text("● READY", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF28204B), Color(0xFF123144))), RoundedCornerShape(19.dp)).padding(15.dp)) {
                Text("IL TUO MASHUP, SENZA COMPLICAZIONI", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black)
                Text("Lascia fare all'app oppure sperimenta con i tuoi controlli.", color = Color(0xFFD1D9EB), fontSize = 10.sp)
                Spacer(Modifier.height(11.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    StatPill("${tracks.size}", "BRANI", Modifier.weight(1f))
                    StatPill(selectedA?.bpm?.toString() ?: "—", "BPM A", Modifier.weight(1f))
                    StatPill(selectedB?.bpm?.toString() ?: "—", "BPM B", Modifier.weight(1f))
                }
            }
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(13.dp)).padding(4.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                listOf("HOME", "MATCH", "MIXER", "STUDIO").forEach { item ->
                    val active = tab == item
                    TextButton(onClick = { tab = item }, modifier = Modifier.weight(1f).background(if (active) Brush.horizontalGradient(listOf(Violet.copy(alpha=.8f), Color(0xFF4C74B8))) else Brush.horizontalGradient(listOf(Panel, Panel)), RoundedCornerShape(10.dp)), contentPadding = PaddingValues(vertical=7.dp)) { Text(item, color = if (active) Color.White else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold) }
                }
            }
            when (tab) {
                "HOME" -> {
                    SectionHeader("PARTIAMO", "Tre passaggi semplici per creare il tuo mix")
                    ActionTile("＋  IMPORTA LE MIE CANZONI", "Scegli file audio dal telefono", Violet) { picker.launch(arrayOf("audio/*")) }
                    ActionTile("✦  FAI TUTTO TU", "Avvia insieme i due brani selezionati", Cyan, enabled = selectedA != null && selectedB != null) { createMashup() }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        MiniTile("1", "ANALIZZA", "BPM e tonalità", Modifier.weight(1f), Cyan) { tab = "MATCH" }
                        MiniTile("2", "ABBINA", "Trova brani", Modifier.weight(1f), Violet) { tab = "MATCH" }
                        MiniTile("3", "MIXA", "Regola l'audio", Modifier.weight(1f), Cyan) { tab = "MIXER" }
                    }
                    SectionHeader("LA MIA LIBRERIA", "Scegli A e B, poi analizza i brani")
                    TrackLibrary(tracks, selectedA, selectedB, analyzingUri, onAnalyze = ::analyzeTrack, onA = { selectedA = it; status = "${it.name} assegnata al Deck A" }, onB = { selectedB = it; status = "${it.name} assegnata al Deck B" }, onPlay = { startDeck(it, true) })
                }
                "MATCH" -> {
                    SectionHeader("SMART ANALYZER", "L'analisi legge l'audio del file selezionato")
                    Text("Seleziona ANALIZZA accanto a un brano. Il risultato viene salvato nella libreria.", color = Muted, fontSize = 10.sp)
                    TrackLibrary(tracks, selectedA, selectedB, analyzingUri, onAnalyze = ::analyzeTrack, onA = { selectedA = it }, onB = { selectedB = it }, onPlay = { startDeck(it, true) })
                    SectionHeader("ABBINAMENTI PER TRACK A", selectedA?.name ?: "Scegli prima il Deck A")
                    if (selectedA != null && matches.isEmpty()) Text("Analizza almeno un altro brano per trovare abbinamenti.", color = Muted, fontSize = 11.sp)
                    matches.take(5).forEach { (track, score) ->
                        Row(Modifier.fillMaxWidth().background(Panel2, RoundedCornerShape(12.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) { Text(track.name, color = Color.White, fontSize = 10.sp, maxLines=1, overflow=TextOverflow.Ellipsis); Text("${track.bpm ?: "—"} BPM · ${track.key ?: "Tonalità —"}", color=Muted, fontSize=9.sp) }
                            Text(if (score > 0) "$score%" else "DA VALUTARE", color=Cyan, fontSize=10.sp, fontWeight=FontWeight.Bold)
                            TextButton(onClick={ selectedB=track; status="${track.name} assegnata al Deck B" }) { Text("USA B", fontSize=9.sp) }
                        }
                    }
                }
                "MIXER" -> {
                    SectionHeader("EASY MIXER", "Due deck, pochi controlli chiari")
                    DeckCard("DECK A", selectedA, Violet, playingA, onPlay = { startDeck(selectedA, true) }, onStop = ::stopDeckA)
                    DeckCard("DECK B", selectedB, Cyan, playingB, onPlay = { startDeck(selectedB, false) }, onStop = ::stopDeckB)
                    Text("BILANCIAMENTO TRA LE DUE CANZONI", color=Color.White, fontSize=10.sp, fontWeight=FontWeight.Bold)
                    Slider(value=crossfade, onValueChange={crossfade=it}, colors=SliderDefaults.colors(thumbColor=Cyan, activeTrackColor=Violet, inactiveTrackColor=Panel2))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween) { Text("Solo A", color=Violet, fontSize=9.sp); Text("Entrambe", color=Muted, fontSize=9.sp); Text("Solo B", color=Cyan, fontSize=9.sp) }
                    Text("Volume Deck A · ${(volumeA*100).toInt()}%", color=Color.White, fontSize=10.sp)
                    Slider(value=volumeA, onValueChange={volumeA=it}, colors=SliderDefaults.colors(thumbColor=Violet, activeTrackColor=Violet))
                    Text("Volume Deck B · ${(volumeB*100).toInt()}%", color=Color.White, fontSize=10.sp)
                    Slider(value=volumeB, onValueChange={volumeB=it}, colors=SliderDefaults.colors(thumbColor=Cyan, activeTrackColor=Cyan))
                    Row(verticalAlignment=Alignment.CenterVertically) { Switch(checked=syncEnabled, onCheckedChange={syncEnabled=it}, colors=SwitchDefaults.colors(checkedThumbColor=Color.White, checkedTrackColor=Violet)); Spacer(Modifier.width(8.dp)); Column { Text("Sincronizzazione BPM", color=Color.White, fontSize=11.sp, fontWeight=FontWeight.Bold); Text("Regola la velocità del Deck B quando i BPM sono disponibili", color=Muted, fontSize=9.sp) } }
                    Button(onClick=::createMashup, modifier=Modifier.fillMaxWidth(), colors=ButtonDefaults.buttonColors(containerColor=Violet)) { Text("▶  AVVIA IL MASHUP", fontWeight=FontWeight.Bold) }
                }
                else -> {
                    SectionHeader("STUDIO CREATIVO", "Scegli quanto vuoi intervenire")
                    Text("Modalità guidata", color=Color.White, fontWeight=FontWeight.Bold, fontSize=13.sp)
                    Text("Se vuoi iniziare subito, torna su HOME e usa FAI TUTTO TU. Se preferisci sperimentare, scegli manualmente i deck e regola il mixer.", color=Muted, fontSize=11.sp)
                    ActionTile("APRI EASY MIXER", "Volume, crossfader e sincronizzazione", Violet) { tab="MIXER" }
                    SectionHeader("I TUOI BRANI", "Analizza e assegna le tracce")
                    TrackLibrary(tracks, selectedA, selectedB, analyzingUri, onAnalyze=::analyzeTrack, onA={selectedA=it}, onB={selectedB=it}, onPlay={startDeck(it,true)})
                    Text("L'editor con tagli, timeline modificabile e file mashup esportabile è previsto per un modulo successivo: questa versione non esporta ancora un mix audio.", color=Muted, fontSize=10.sp)
                }
            }
            Spacer(Modifier.height(2.dp))
            Text(status, color=Muted, fontSize=9.sp, maxLines=2, overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable private fun StatPill(value: String, label: String, modifier: Modifier) {
    Column(modifier.background(Color.Black.copy(alpha=.2f), RoundedCornerShape(10.dp)).padding(8.dp)) { Text(value, color=Color.White, fontWeight=FontWeight.Black, fontSize=16.sp); Text(label, color=Color(0xFFB8C6DF), fontSize=8.sp, fontWeight=FontWeight.Bold) }
}
@Composable private fun SectionHeader(title: String, subtitle: String) { Column(verticalArrangement=Arrangement.spacedBy(2.dp)) { Text(title, color=Color.White, fontSize=13.sp, fontWeight=FontWeight.Black, letterSpacing=1.sp); Text(subtitle, color=Muted, fontSize=10.sp) } }
@Composable private fun ActionTile(title: String, subtitle: String, accent: Color, enabled: Boolean = true, onClick: () -> Unit) {
    Button(onClick=onClick, enabled=enabled, modifier=Modifier.fillMaxWidth().height(55.dp), shape=RoundedCornerShape(14.dp), colors=ButtonDefaults.buttonColors(containerColor=accent, disabledContainerColor=Panel2)) { Column(horizontalAlignment=Alignment.CenterHorizontally) { Text(title, color=Color.White, fontSize=12.sp, fontWeight=FontWeight.Black); Text(subtitle, color=Color.White.copy(alpha=.82f), fontSize=9.sp) } }
}
@Composable private fun MiniTile(number: String, title: String, subtitle: String, modifier: Modifier, accent: Color, onClick: () -> Unit) {
    Surface(onClick=onClick, modifier=modifier, color=Panel, shape=RoundedCornerShape(14.dp), border=androidx.compose.foundation.BorderStroke(1.dp, accent.copy(alpha=.28f))) { Column(Modifier.padding(10.dp), verticalArrangement=Arrangement.spacedBy(4.dp)) { Text(number, color=accent, fontSize=9.sp, fontWeight=FontWeight.Black); Text(title, color=Color.White, fontSize=9.sp, fontWeight=FontWeight.Bold); Text(subtitle, color=Muted, fontSize=8.sp) } }
}
@Composable private fun TrackLibrary(tracks: List<AudioTrack>, selectedA: AudioTrack?, selectedB: AudioTrack?, analyzingUri: String?, onAnalyze: (AudioTrack)->Unit, onA:(AudioTrack)->Unit, onB:(AudioTrack)->Unit, onPlay:(AudioTrack)->Unit) {
    if (tracks.isEmpty()) Text("La libreria è vuota. Importa i tuoi brani per iniziare.", color=Muted, fontSize=11.sp)
    else LazyColumn(Modifier.heightIn(max=300.dp), verticalArrangement=Arrangement.spacedBy(7.dp)) {
        items(tracks, key={it.uri.toString()}) { track ->
            Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(horizontal=8.dp, vertical=7.dp), verticalAlignment=Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(track.name, color=Color.White, fontSize=10.sp, fontWeight=FontWeight.SemiBold, maxLines=1, overflow=TextOverflow.Ellipsis)
                    Text(if (track.analyzed) "${track.bpm ?: "—"} BPM · ${track.key ?: "Tonalità —"} · Energia ${track.energy ?: "—"}" else "Non analizzato · premi ANALIZZA", color=Muted, fontSize=8.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
                }
                TextButton(onClick={onAnalyze(track)}, enabled=analyzingUri==null, contentPadding=PaddingValues(horizontal=3.dp)) { Text(if (analyzingUri==track.uri.toString()) "…" else "ANALIZZA", color=Violet, fontSize=8.sp) }
                TextButton(onClick={onA(track)}, contentPadding=PaddingValues(horizontal=2.dp)) { Text(if(selectedA?.uri==track.uri) "A✓" else "A", color=Violet, fontSize=10.sp) }
                TextButton(onClick={onB(track)}, contentPadding=PaddingValues(horizontal=2.dp)) { Text(if(selectedB?.uri==track.uri) "B✓" else "B", color=Cyan, fontSize=10.sp) }
                TextButton(onClick={onPlay(track)}, contentPadding=PaddingValues(horizontal=2.dp)) { Text("▶", color=Color.White, fontSize=10.sp) }
            }
        }
    }
}
@Composable private fun DeckCard(title:String, track:AudioTrack?, accent:Color, playing:Boolean, onPlay:()->Unit, onStop:()->Unit) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(15.dp)).border(1.dp, accent.copy(alpha=.35f), RoundedCornerShape(15.dp)).padding(12.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) {
        Row(verticalAlignment=Alignment.CenterVertically) { Text(title, color=accent, fontWeight=FontWeight.Black, fontSize=10.sp); Spacer(Modifier.weight(1f)); Text(if(playing) "● IN RIPRODUZIONE" else "● PRONTO", color=if(playing) Cyan else Muted, fontSize=8.sp) }
        Text(track?.name ?: "Scegli una traccia dalla HOME", color=Color.White, fontSize=11.sp, maxLines=1, overflow=TextOverflow.Ellipsis)
        Text("${track?.bpm?.let{"$it BPM"} ?: "BPM —"} · ${track?.key ?: "Tonalità —"}", color=Muted, fontSize=9.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { Button(onClick=onPlay, colors=ButtonDefaults.buttonColors(containerColor=accent), contentPadding=PaddingValues(horizontal=16.dp, vertical=7.dp)) { Text("▶ PLAY", fontSize=9.sp) }; OutlinedButton(onClick=onStop, contentPadding=PaddingValues(horizontal=16.dp, vertical=7.dp)) { Text("STOP", fontSize=9.sp) } }
    }
}
